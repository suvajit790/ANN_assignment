----------------------------------------
~~~~       Dataset Information      ~~~~
----------------------------------------

5629 grayscale images of Oriya numerals in TIF format.

Class Distribution:
--------------------
0 : 359 instances
1 : 592 instances
2 : 591 instances
3 : 591 instances
4 : 594 instances
5 : 589 instances
6 : 555 instances
7 : 578 instances
8 : 592 instances
9 : 588 instances
--------------------

Copyright (c) 1995 - 2018 Computer Vision and Pattern Recognition Unit, Indian Statistical Institute.
